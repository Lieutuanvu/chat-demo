var socket=io("http://localhost:3000");
socket.on("dk_that_bai",function(){
    alert("Tai khoan da ton tai");
});
socket.on("danh_sach_user",function(data){
    $("#box-user-content").html("");
    data.forEach(function(i){
        $("#box-user-content").append("<div class='user'>"+i+"</div>");
    });
})
socket.on("dk_thanh_cong",function(data){
    alert("Thanh cong, xin chao "+data);
    $("#userHientai").html(data);
    $("#login").hide(2000);
    $("#chat").show(1000);
    $("#sendMessage").click(function(){
        if ($("#txtMessage").val()!=""){
            socket.emit("message",$("#txtMessage").val());
            $("#txtMessage").val("");
        }
    })

});
socket.on("message_all",function(data){
    $("#message").append("<div class='ms'>"+data.us+" nói: "+data.nd+"</div>")
})
socket.on("user_dang_text",function(data){
    $("#dang-text").append(data+ " đang nhập tin nhắn");
})
socket.on("user_ngung_text",function(data){
    $("#dang-text").html("");
})
$(document).ready(function(){
    $("#txtMessage").focusin(function(){
        socket.emit("dang_text");
    })
    $("#txtMessage").focusout(function(){
        socket.emit("ngung_text");
    })

    $("#login").show();
    $("#chat").hide();
    $("#dangky").click(function(){
        socket.emit("dangky",$("#user").val());
    })
    $("#dangxuat").click(function(){
        socket.emit("dangxuat",$("#user").val());
        $("#login").show(1000);
        $("#chat").hide(2000);
    })

})